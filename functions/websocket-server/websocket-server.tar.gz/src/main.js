import { WebSocketServer } from 'ws';
import { Client, Databases, ID } from 'node-appwrite';

// Initialize Appwrite client
const client = new Client()
  .setEndpoint(process.env.APPWRITE_FUNCTION_ENDPOINT || 'https://cloud.appwrite.io/v1')
  .setProject(process.env.APPWRITE_FUNCTION_PROJECT_ID)
  .setKey(process.env.APPWRITE_API_KEY);

const databases = new Databases(client);

// WebSocket server instance
let wss = null;
const connectedClients = new Set();

// In-memory storage for demo mode
const deviceStorage = new Map();
const sensorDataStorage = new Map();
const alertStorage = new Map();

// Demo data cycling
let fishDataIndex = 0;
let plantDataIndex = 0;
const fishDemoData = [];
const plantDemoData = [];

// Load demo data (this would be loaded from CSV in real implementation)
const loadDemoData = () => {
  // Fish demo data
  fishDemoData.push(
    { timestamp: new Date().toISOString(), waterTemp: 29.48, ec: 318.75, tds: 204, turbidity: 12, ph: 6.8 },
    { timestamp: new Date().toISOString(), waterTemp: 28.65, ec: 321.875, tds: 206, turbidity: 10, ph: 7.2 },
    { timestamp: new Date().toISOString(), waterTemp: 29.76, ec: 323.4375, tds: 207, turbidity: 12, ph: 7.0 }
  );
  
  // Plant demo data
  plantDemoData.push(
    { timestamp: new Date().toISOString(), height: 10, plantTemp: 30.12, humidity: 64.35, pressure: 100218.29 },
    { timestamp: new Date().toISOString(), height: 10, plantTemp: 31.57, humidity: 67.8, pressure: 100209.74 },
    { timestamp: new Date().toISOString(), height: 10, plantTemp: 32.48, humidity: 72.36, pressure: 100203.85 }
  );
};

// Initialize WebSocket server
const initializeWebSocket = (port = 3001) => {
  if (wss) {
    console.log('WebSocket server already running');
    return;
  }

  wss = new WebSocketServer({ port });
  console.log(`WebSocket server started on port ${port}`);

  wss.on('connection', (ws, req) => {
    console.log('New WebSocket connection established');
    connectedClients.add(ws);

    // Send initial connection confirmation
    ws.send(JSON.stringify({
      type: 'connection_established',
      timestamp: new Date().toISOString(),
      message: 'Connected to AquaNexus WebSocket server'
    }));

    // Handle incoming messages
    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        await handleWebSocketMessage(message, ws);
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
        ws.send(JSON.stringify({
          type: 'error',
          message: 'Invalid message format',
          timestamp: new Date().toISOString()
        }));
      }
    });

    // Handle connection close
    ws.on('close', () => {
      console.log('WebSocket connection closed');
      connectedClients.delete(ws);
    });

    // Handle errors
    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      connectedClients.delete(ws);
    });
  });
};

// Handle WebSocket messages
const handleWebSocketMessage = async (message, ws) => {
  const { type, data } = message;

  switch (type) {
    case 'esp32_data':
      await handleESP32Data(data);
      break;
    case 'device_registration':
      await handleDeviceRegistration(data);
      break;
    case 'heartbeat':
      await handleHeartbeat(data);
      break;
    case 'get_devices':
      await sendDeviceList(ws);
      break;
    case 'get_sensor_data':
      await sendSensorData(ws, data.deviceId);
      break;
    default:
      console.log('Unknown message type:', type);
  }
};

// Handle ESP32 sensor data
const handleESP32Data = async (data) => {
  const { deviceId, sensorType, readings, timestamp } = data;
  
  // Store sensor data
  if (!sensorDataStorage.has(deviceId)) {
    sensorDataStorage.set(deviceId, []);
  }
  
  const deviceData = sensorDataStorage.get(deviceId);
  deviceData.push({
    timestamp: timestamp || new Date().toISOString(),
    sensorType,
    readings
  });
  
  // Keep only last 100 readings
  if (deviceData.length > 100) {
    deviceData.splice(0, deviceData.length - 100);
  }
  
  // Check for alerts
  const alerts = checkForAlerts(sensorType, readings);
  if (alerts.length > 0) {
    alerts.forEach(alert => {
      alertStorage.set(ID.unique(), {
        deviceId,
        type: alert.type,
        message: alert.message,
        severity: alert.severity,
        timestamp: new Date().toISOString(),
        resolved: false
      });
    });
  }
  
  // Broadcast to all connected clients
  broadcastToClients({
    type: 'sensor_reading',
    deviceId,
    sensorType,
    readings,
    timestamp: timestamp || new Date().toISOString()
  });
  
  // Broadcast alerts if any
  if (alerts.length > 0) {
    alerts.forEach(alert => {
      broadcastToClients({
        type: 'system_alert',
        deviceId,
        alert
      });
    });
  }
};

// Handle device registration
const handleDeviceRegistration = async (data) => {
  const { deviceId, deviceName, deviceType, apiKey } = data;
  
  deviceStorage.set(deviceId, {
    id: deviceId,
    name: deviceName,
    type: deviceType,
    apiKey,
    status: 'online',
    lastSeen: new Date().toISOString(),
    registeredAt: new Date().toISOString()
  });
  
  broadcastToClients({
    type: 'device_registered',
    device: deviceStorage.get(deviceId)
  });
};

// Handle heartbeat
const handleHeartbeat = async (data) => {
  const { deviceId } = data;
  
  if (deviceStorage.has(deviceId)) {
    const device = deviceStorage.get(deviceId);
    device.lastSeen = new Date().toISOString();
    device.status = 'online';
    
    broadcastToClients({
      type: 'device_status',
      deviceId,
      status: 'online',
      lastSeen: device.lastSeen
    });
  }
};

// Send device list
const sendDeviceList = async (ws) => {
  const devices = Array.from(deviceStorage.values());
  ws.send(JSON.stringify({
    type: 'device_list',
    devices,
    timestamp: new Date().toISOString()
  }));
};

// Send sensor data
const sendSensorData = async (ws, deviceId) => {
  const data = sensorDataStorage.get(deviceId) || [];
  ws.send(JSON.stringify({
    type: 'sensor_data',
    deviceId,
    data,
    timestamp: new Date().toISOString()
  }));
};

// Check for alerts based on sensor readings
const checkForAlerts = (sensorType, readings) => {
  const alerts = [];
  
  if (sensorType === 'fish') {
    // Fish environment alerts
    if (readings.waterTemp < 25 || readings.waterTemp > 32) {
      alerts.push({
        type: 'temperature_alert',
        message: `Water temperature ${readings.waterTemp}°C is outside optimal range (25-32°C)`,
        severity: 'warning'
      });
    }
    
    if (readings.ph < 6.5 || readings.ph > 7.5) {
      alerts.push({
        type: 'ph_alert',
        message: `pH level ${readings.ph} is outside optimal range (6.5-7.5)`,
        severity: 'warning'
      });
    }
    
    if (readings.turbidity > 25) {
      alerts.push({
        type: 'turbidity_alert',
        message: `High turbidity detected: ${readings.turbidity} NTU`,
        severity: 'warning'
      });
    }
  } else if (sensorType === 'plant') {
    // Plant environment alerts
    if (readings.plantTemp < 20 || readings.plantTemp > 35) {
      alerts.push({
        type: 'temperature_alert',
        message: `Plant temperature ${readings.plantTemp}°C is outside optimal range (20-35°C)`,
        severity: 'warning'
      });
    }
    
    if (readings.humidity < 60 || readings.humidity > 80) {
      alerts.push({
        type: 'humidity_alert',
        message: `Humidity ${readings.humidity}% is outside optimal range (60-80%)`,
        severity: 'warning'
      });
    }
  }
  
  return alerts;
};

// Broadcast message to all connected clients
const broadcastToClients = (message) => {
  const messageStr = JSON.stringify(message);
  connectedClients.forEach(client => {
    if (client.readyState === 1) { // WebSocket.OPEN
      client.send(messageStr);
    }
  });
};

// Demo mode data streaming
const startDemoDataStreaming = () => {
  setInterval(() => {
    // Stream fish data
    if (fishDemoData.length > 0) {
      const fishData = fishDemoData[fishDataIndex % fishDemoData.length];
      fishData.timestamp = new Date().toISOString();
      
      broadcastToClients({
        type: 'sensor_reading',
        deviceId: 'demo-fish-001',
        sensorType: 'fish',
        readings: {
          waterTemp: fishData.waterTemp,
          ec: fishData.ec,
          tds: fishData.tds,
          turbidity: fishData.turbidity,
          ph: fishData.ph
        },
        timestamp: fishData.timestamp
      });
      
      fishDataIndex++;
    }
    
    // Stream plant data
    if (plantDemoData.length > 0) {
      const plantData = plantDemoData[plantDataIndex % plantDemoData.length];
      plantData.timestamp = new Date().toISOString();
      
      broadcastToClients({
        type: 'sensor_reading',
        deviceId: 'demo-plant-001',
        sensorType: 'plant',
        readings: {
          height: plantData.height,
          plantTemp: plantData.plantTemp,
          humidity: plantData.humidity,
          pressure: plantData.pressure
        },
        timestamp: plantData.timestamp
      });
      
      plantDataIndex++;
    }
  }, 5000); // Stream every 5 seconds
};

// Main function handler
export default async ({ req, res, log, error }) => {
  try {
    const method = req.method;
    const path = req.path;
    
    log('WebSocket function called:', { method, path });
    
    if (method === 'GET' && path === '/ws') {
      // Initialize WebSocket server if not already running
      if (!wss) {
        loadDemoData();
        initializeWebSocket();
        
        // Start demo data streaming (this would be controlled by mode settings)
        // startDemoDataStreaming();
      }
      
      return res.json({
        success: true,
        message: 'WebSocket server is running',
        endpoint: 'ws://localhost:3001/ws',
        timestamp: new Date().toISOString()
      });
    }
    
    if (method === 'POST' && path === '/start-demo') {
      loadDemoData();
      startDemoDataStreaming();
      
      return res.json({
        success: true,
        message: 'Demo mode started',
        timestamp: new Date().toISOString()
      });
    }
    
    if (method === 'GET' && path === '/status') {
      return res.json({
        success: true,
        status: 'running',
        connectedClients: connectedClients.size,
        devices: deviceStorage.size,
        timestamp: new Date().toISOString()
      });
    }
    
    return res.json({
      success: false,
      message: 'Invalid endpoint',
      availableEndpoints: ['/ws', '/start-demo', '/status']
    });
    
  } catch (err) {
    error('WebSocket function error:', err);
    return res.json({
      success: false,
      message: 'Internal server error',
      error: err.message
    }, 500);
  }
};