import main from './main.js';

export default main;